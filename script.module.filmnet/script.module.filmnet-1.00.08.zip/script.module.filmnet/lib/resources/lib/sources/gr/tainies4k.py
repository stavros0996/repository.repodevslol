# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re, base64

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['gr']
        self.domains = ['tainies4k.online']
        self.base_link = 'http://tainies4k.online/'
        self.search_link = '?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases),year)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = [{'url': url, 'season': season, 'episode': episode}]
            return url
        except:
            return

    def __search(self, titles, year):
        try:
            tit = [i.split(':')[0] for i in titles]
            query = [self.search_link % (urllib.quote_plus(cleantitle.getsearch(i))) for i in tit]
            query = [urlparse.urljoin(self.base_link, i) for i in query]
            t = [cleantitle.get(i) for i in set(titles) if i]
            for u in query:
                try:
                    r = client.request(u)
                    r = client.parseDOM(r, 'div', attrs={'id': 'mt-\d+'})
                    r = [(client.parseDOM(i, 'a', ret='href')[0],
                          client.parseDOM(i, 'span', attrs={'class':'tt'}),
                          client.parseDOM(i, 'span', attrs={'class':'year'})) for i in r if i]
                    r = [(i[0], i[1][0], i[2][0]) for i in r if i[2]]
                    r = [(i[0]) for i in r if (year == i[2] and cleantitle.get(i[1]) in t)]
                    url = source_utils.strip_domain(r[0])

                    return url
                except:
                    pass

            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            if type(url) is list:
                url = url[0]
                query, season, episode = url['url'], url['season'], url['episode']
                query = urlparse.urljoin(self.base_link, query)
                r = client.request(query)
                r = client.parseDOM(r, 'div', attrs={'class':'contenidotv'})
                links = client.parseDOM(r, 'table', attrs={'class': 'easySpoilerTable'})

                pattern = 'Σεζόν %d' % int(season)
                links = [i for i in links if pattern.decode('utf-8') in i]
                links = dom_parser2.parse_dom(links[0], 'a', req='href')
                links = [(i.attrs['href'], i.content) for i in links if '%02d' % int(episode) in i.content]
                links = [i[0] for i in links]


            else:
                query = urlparse.urljoin(self.base_link, url)
                r = client.request(query)
                links = client.parseDOM(r, 'ul', attrs={'class':'enlaces'})
                links = client.parseDOM(links, 'li', attrs={'class':'elemento'})
                links = client.parseDOM(links, 'a', ret='href')

            for url in links:
                try:
                    url = re.sub('http://adf.ly/\w+/','', url)

                    if 'streamcrypt' in url:
                        url = client.request(url, output='geturl', redirect=True)

                    if 'redvid' in url:
                        data = client.request(url)
                        url = client.parseDOM(data, 'iframe', ret='src')[0]

                    if any(x in url for x in ['.online', 'xrysoi.se', 'filmer', '.bp', '.blogger', 'youtu']):
                        continue

                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if not valid: continue
                    quality = 'SD'
                    lang, info = 'gr', 'SUB'

                    sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                    'direct':False,'debridonly': False})
                except:
                    pass
            return sources
        except:
            return sources

    def resolve(self, url):

        return url