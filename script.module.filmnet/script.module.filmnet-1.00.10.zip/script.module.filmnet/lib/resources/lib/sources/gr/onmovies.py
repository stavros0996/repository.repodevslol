# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re, base64,json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import unjuice


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['gr']
        self.domains = ['onlinemovie.gr']
        self.base_link = 'https://onlinemovie.gr'
        self.search_link = '/wp-json/dooplay/search/?keyword=%s&nonce=550898deed'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases), year)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = url[:-1] if url.endswith('/') else url
            t = url.split('/')[-1]
            url = self.base_link + '/episodes/' + t + '-%dx%d' % (int(season), int(episode))

            return url
        except:
            return

    def __search(self, titles, year):
        try:
            tit = [i.split(':')[0] for i in titles]
            query = [self.search_link % (urllib.quote_plus(cleantitle.getsearch(i))) for i in tit]
            query = [urlparse.urljoin(self.base_link, i) for i in query]
            t = [cleantitle.get(i) for i in set(titles) if i]
            for u in query:
                try:
                    r = client.request(u)
                    r = json.loads(r)
                    r = [(r[i]['url'], r[i]['title'], r[i]['extra']) for i in r if i]
                    r = [(i[0], i[1]) for i in r if i[2]['date'] == year ]
                    if len(r) == 1: return source_utils.strip_domain(r[0][0])
                    else:
                        r = [(i[0]) for i in r if cleantitle.get(i[1]) in t]
                        return source_utils.strip_domain(r[0])

                except:
                    pass

            return
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            query = urlparse.urljoin(self.base_link, url)
            r = client.request(query)
            r1 = client.parseDOM(r, 'div', attrs={'class':'playex'})
            links = dom_parser2.parse_dom(r1, 'iframe', req='src')
            tabs = dom_parser2.parse_dom(r, 'a', attrs={'class':'options'})
            links = [(links[i].attrs['src'], tabs[i].content) for i in range(len(links))]
            links = [(i[0], i[1]) for i in links if not 'youtube' in i[0]]

            extra = client.parseDOM(r, 'div', attrs={'id':'views'})
            extra = dom_parser2.parse_dom(extra, 'td')
            extra = [dom_parser2.parse_dom(i.content, 'img', req='src') for i in extra if i]
            extra = [(i[0].attrs['src'] ,dom_parser2.parse_dom(i[0].content, 'a', req='href')) for i in extra if i]
            extra = [(re.findall('domain=(.+?)$', i[0])[0], i[1][0].attrs['href']) for i in extra if i]

            for item in links:
                url = item[0]
                lang, info = 'gr', 'SUB'
                quality, info2 = source_utils.get_release_quality(item[1], None)
                try:
                    if 'player' in url:
                        url = re.findall('source=(.+?)&sub', url)[0]
                        url = base64.b64decode(url)
                        if 'cdn' in url or 'nd' in url:
                            sources.append(
                                {'source': 'CDN', 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                 'direct': True, 'debridonly': False})
                except:
                    pass

                try:
                    if 'api' in url:
                        data = client.request(url)
                        if not unjuice.test(data): raise Exception()
                        r = unjuice.run(data)
                        urls = re.findall('''file['"]:['"]([^'"]+).+?label":['"]([^'"]+)''', r, re.DOTALL)
                        for i in urls:
                            if 'google' in i[0]:
                                host, direct = 'GVIDEO', False
                                quality, url = i[1], i[0]
                                sources.append(
                                    {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                     'direct': direct, 'debridonly': False})
                            else: continue
                except:pass

            for item in extra:
                url = item[1]
                quality = 'SD'
                lang, info = 'gr', 'SUB'
                valid, host = source_utils.is_host_valid(item[0], hostDict)
                if not valid: continue
                if 'streamcloud' in host: continue

                sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                'direct': False, 'debridonly': False})

            return sources
        except:
            return sources

    def resolve(self, url):
        if 'onlinemovie' in url:
            url = client.request(url, output='geturl', redirect=True)
        return url