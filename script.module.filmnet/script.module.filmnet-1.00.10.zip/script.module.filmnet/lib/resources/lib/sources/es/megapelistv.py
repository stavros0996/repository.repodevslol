# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2



class source:
    def __init__(self):
        self.priority = 1
        self.language = ['es']
        self.domains = ['megapelistv.com']
        self.base_link = 'http://megapelistv.com/'
        self.search_link = '/?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases),year)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:

            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search([tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = url[:-1] if url.endswith('/') else url
            title = url.split('/')[2]
            url = '/episodes/%s-%dx%d/' % (title, int(season), int(episode))
            url = urlparse.urljoin(self.base_link, url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            query = urlparse.urljoin(self.base_link, url)

            r = client.request(query)

            data = client.parseDOM(r, 'div', attrs={'id': 'downloads'})
            data += client.parseDOM(r, 'div', attrs={'id': 'views'})

            links = client.parseDOM(data, 'tbody')
            links = dom_parser2.parse_dom(links, 'tr') #<tr id="movrUA1yF295693">
            links = [(client.parseDOM(i.content, 'a', ret='href')[0],
                      client.parseDOM(i.content, 'img', ret='src')[0],
                      client.parseDOM(i.content, 'td')[2],
                      client.parseDOM(i.content, 'td')[3]) for i in links if i]
            links = [(i[0], re.findall('domain=(.+?)$', i[1])[0], i[2],i[3]) for i in links if i]

            for url, host, qual, idioma in links:
                if 'Latino' in idioma:
                    lang, info = 'es', 'LAT'
                else:
                    lang, info = 'es', None
                if 'HD' in qual: q = 'HD'
                else: q = 'SD'

                if host in hostDict: d = False
                elif host in hostprDict: d = True
                else: raise Exception()

                sources.append(
                    {'source': host, 'quality': q, 'language': lang, 'url': url, 'info': info, 'direct': False,
                     'debridonly': d})

            return sources
        except:
            return sources

    def __search(self, titles, year):
        try:

            query = [self.search_link % (urllib.quote_plus(cleantitle.getsearch(i))) for i in titles]

            query = [urlparse.urljoin(self.base_link, i) for i in query if i]

            t = [cleantitle.get(i) for i in set(titles) if i]
            for u in query:
                try:
                    r = client.request(u)

                    r = client.parseDOM(r, 'div', attrs={'class': 'details'})
                    data = [(dom_parser2.parse_dom(i, 'div', attrs={'class': 'title'})[0],
                             dom_parser2.parse_dom(i, 'span', attrs={'class': 'year'})[0]) for i in r if i]
                    data = [(dom_parser2.parse_dom(i[0].content, 'a'), i[1].content) for i in data if i]
                    data = [(i[0][0].attrs['href'], i[0][0].content, i[1]) for i in data if i[1] == year]
                    data = [i[0] for i in data if  cleantitle.get(i[1]) in t]
                    url = source_utils.strip_domain(data[0])
                    return url
                except:
                    pass

            return
        except:
            return


    def resolve(self, url):
        if 'megapelistv' in url:
            url = client.request(url.replace('https://www.', 'http://'))
            url = client.parseDOM(url, 'a', ret='href')[0]

        return url