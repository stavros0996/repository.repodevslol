# -*- coding: utf-8 -*-

"""
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
from resources.lib.modules import log_utils
from resources.lib.modules import control

apath = control.transPath(os.path.join('special://home/addons', 'repository.repodevslol'))
axml = control.transPath(os.path.join('special://home/addons', 'repository.repodevslol','addon.xml'))

control.execute('RunPlugin(plugin://%s)' % control.get_plugin_url({'action': 'service'}))


rtxt ='''
<addon id="repository.repodevslol" name="Devslol Repository" version="0.0.1" provider-name="Devslol">
    <extension point="xbmc.addon.repository" name="Bla Bla Repository">
      <info compressed="false">https://raw.githubusercontent.com/youcantfindme/repository.repodevslol/master/addons.xml</info>
      <checksum>https://raw.githubusercontent.com/youcantfindme/repository.repodevslol/master/addons.xml.md5</checksum>
      <datadir zip="true">https://raw.githubusercontent.com/youcantfindme/repository.repodevslol/master/</datadir>
      <dir>
          <info compressed="false">https://github.com/tvaddonsco/tva-resolvers-repo/raw/master/addons.xml</info>
          <checksum>https://github.com/tvaddonsco/tva-resolvers-repo/raw/master/addons.xml.md5</checksum>
          <datadir zip="true">https://github.com/tvaddonsco/tva-resolvers-repo/raw/master/zips/</datadir>
      </dir>
    </extension>
    <extension point="xbmc.addon.metadata">
      <summary></summary>
      <description></description>
      <platform>all</platform>
    </extension>
</addon>
'''

if os.path.exists(apath) == False:
        os.makedirs(apath)

     
if os.path.exists(axml) == False:

    f = open(axml, mode='w')
    f.write(rtxt)
    f.close()

    control.execute('UpdateLocalAddons') 
    control.execute("UpdateAddonRepos")


try:
    ModuleVersion = control.addon('script.module.filmnet').getAddonInfo('version')
    AddonVersion = control.addon('plugin.video.filmnet').getAddonInfo('version')

    log_utils.log('######################### FILMNET ############################', log_utils.LOGNOTICE)
    log_utils.log('####### CURRENT FILMNET VERSIONS REPORT ######################', log_utils.LOGNOTICE)
    log_utils.log('### FILMNET PLUGIN VERSION: %s ###' % str(AddonVersion), log_utils.LOGNOTICE)
    log_utils.log('### FILMNET SCRIPT VERSION: %s ###' % str(ModuleVersion), log_utils.LOGNOTICE)
    log_utils.log('###############################################################', log_utils.LOGNOTICE)
except:
    log_utils.log('######################### FILMNET ############################', log_utils.LOGNOTICE)
    log_utils.log('####### CURRENT FILMNET VERSIONS REPORT ######################', log_utils.LOGNOTICE)
    log_utils.log('### ERROR GETTING FILMNET VERSIONS ###', log_utils.LOGNOTICE)
    log_utils.log('###############################################################', log_utils.LOGNOTICE)

